# Vishnu Kumar — Personal Portfolio

## Run locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository (for example `vishnu-portfolio`).
2. Upload `index.html` to the repository root and commit the file.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for deployment. Your public URL will look like `https://YOUR-GITHUB-USERNAME.github.io/vishnu-portfolio/`.
6. Open that URL in an incognito/private window to verify public access.

Replace the sample name if needed and add your real second project, registration number, school, and any verified achievements before submission.
